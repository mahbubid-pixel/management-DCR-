# ManagementDCR22 — Phase 7 Android build package

This is a **demo-only** reconstructed source project. No production login, real doctor directory, or live DCR submission is connected. Do not enter real business or patient data.

## Android-only build using GitHub Actions
1. On your phone, create a **private** GitHub repository. Do not upload credentials, tokens, captured packets, or real DCR data.
2. Upload the *contents* of this ZIP to the repository root, including `.github/workflows/build-debug-apk.yml` (the `.github` folder may be hidden in some file managers).
3. In GitHub, open **Actions → Build demo Android APK → Run workflow**. A push to `main` can also trigger the build.
4. Wait for the workflow result. If it succeeds, open the workflow run and download the `ManagementDCR-demo-debug-apk` artifact.
5. Extract `app-debug.apk` and install it on your phone only after checking the source and confirming the artifact comes from your repository. Android may request permission to install from your file manager.

This is a debug-signed APK for personal testing, not a production release. It uses a separate package name from the original app. If the workflow fails, share the **non-sensitive build error log** for correction.

## Limitations
- This environment lacked Android SDK, Gradle, and network access; APK compilation could not be performed here.
- No build success is claimed. The GitHub workflow will perform the first actual compilation.
- App data stored as offline drafts is not application-layer encrypted.
- Backend authentication, server APIs, and production DCR submission remain disabled.
