package com.example.managementdcr.api

/**
 * Phase 5: explicit contract and authorization gate. No guessed requests are sent.
 * Implement this interface only after method, schema and auth verification in staging.
 */
data class VerifiedEndpoint(
    val path: String,
    val method: HttpMethod,
    val requiresAuthentication: Boolean,
    val requestSchemaVersion: String,
    val responseSchemaVersion: String
)
enum class HttpMethod { GET, POST, PUT, PATCH, DELETE }

data class VerifiedApiContract(
    val baseUrl: String,
    val login: VerifiedEndpoint,
    val doctors: VerifiedEndpoint,
    val brands: VerifiedEndpoint,
    val dashboard: VerifiedEndpoint,
    val dcrSubmission: VerifiedEndpoint
)

sealed interface LoginResult {
    data class Authenticated(val userDisplayName: String): LoginResult
    data class Failed(val reason: String): LoginResult
}

interface SecureAuthGateway {
    suspend fun signIn(username: String, password: CharArray): LoginResult
    suspend fun signOut()
}

/** Prevents accidental production requests while API contracts are unverified. */
class DisabledAuthGateway : SecureAuthGateway {
    override suspend fun signIn(username: String, password: CharArray): LoginResult {
        password.fill('\u0000')
        return LoginResult.Failed("Authentication is disabled until staging API verification")
    }
    override suspend fun signOut() = Unit
}

object ApiIntegrationGate {
    const val ENABLED = false
    fun verifiedContractOrNull(): VerifiedApiContract? = null
}
