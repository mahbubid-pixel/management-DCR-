package com.example.managementdcr.api

/** Pure policy for preventing a preview draft from being represented as a server submission. */
enum class RecordState { LOCAL_DRAFT, PENDING_VERIFICATION, SERVER_ACCEPTED }

data class SubmissionDecision(val allowed: Boolean, val reason: String)

object SubmissionPolicy {
    fun canSubmit(contractVerified: Boolean, authenticated: Boolean, stagingApproved: Boolean): SubmissionDecision = when {
        !ApiIntegrationGate.ENABLED -> SubmissionDecision(false, "Live integration disabled")
        !contractVerified -> SubmissionDecision(false, "API contract not verified")
        !authenticated -> SubmissionDecision(false, "Authentication required")
        !stagingApproved -> SubmissionDecision(false, "Staging authorization required")
        else -> SubmissionDecision(true, "Eligible for approved staging request")
    }
    fun serverAccepted(httpSuccess: Boolean, responseConfirmed: Boolean): RecordState =
        if (httpSuccess && responseConfirmed) RecordState.SERVER_ACCEPTED else RecordState.PENDING_VERIFICATION
}
