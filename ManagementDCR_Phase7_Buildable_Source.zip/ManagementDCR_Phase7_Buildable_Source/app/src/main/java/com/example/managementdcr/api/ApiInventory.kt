package com.example.managementdcr.api

/**
 * Static route inventory recovered from original APK DEX string table.
 * These are NOT verified HTTP methods, schemas, or callable production APIs.
 * No requests are made by this module.
 */
object ApiInventory {
    const val HOST = "https://workplan.acibd.com/"
    const val LOGIN = "authenticate/login"
    const val DOCTORS = "doctor-info/{level}"
    const val DOCTOR_PRIORITY = "doctor-priority-info/{level1}/{doctorId}"
    const val AREAS = "area-info/{level3}"
    const val TERRITORIES = "territory-info/{level2}/{SBID}"
    const val BRANDS = "region-brand-info/{SBId}"
    const val DCR_LIST = "dcr-list"
    const val DCR_DETAILS = "dcr-details/{dcrID}"
    const val DCR_ADD = "dcr-add"
    const val DASHBOARD = "my-dcr-dashboard"
    const val GENERAL = "general-info"
    const val GIFTS = "get-user-gift-list"
}

/** Explicitly separated transport interface: do not guess methods or send credentials. */
interface AuthorizedDcrGateway {
    suspend fun loadDoctorCatalog(scope: DoctorScope): GatewayResult<List<DoctorSummary>>
    suspend fun loadTargetBrands(scope: DoctorScope): GatewayResult<List<BrandSummary>>
    suspend fun loadDashboard(): GatewayResult<DashboardSummary>
}

data class DoctorScope(val businessId: String, val regionId: String, val areaId: String, val fmeId: String)
data class DoctorSummary(val id: String, val displayName: String, val priority: String?, val lastCall: String?)
data class BrandSummary(val id: String, val displayName: String)
data class DashboardSummary(val dcrCalls: Int, val plannedCalls: Int?)
sealed interface GatewayResult<out T> {
    data class Success<T>(val value: T): GatewayResult<T>
    data class Unavailable(val reason: String): GatewayResult<Nothing>
}

/** Safe default until HTTP verbs, request contracts, authorization and staging are verified. */
class UnconfiguredGateway : AuthorizedDcrGateway {
    override suspend fun loadDoctorCatalog(scope: DoctorScope) = GatewayResult.Unavailable("Doctor API contract unverified")
    override suspend fun loadTargetBrands(scope: DoctorScope) = GatewayResult.Unavailable("Brand API contract unverified")
    override suspend fun loadDashboard() = GatewayResult.Unavailable("Dashboard API contract unverified")
}
