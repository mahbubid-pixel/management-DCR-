package com.example.managementdcr

import android.os.Bundle
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Blue = Color(0xFF165BB5)
private val Background = Color(0xFFF2F6FC)
private val Brands = listOf("Abecab", "Abetis", "Aptin", "Arbitel", "Avloclav", "Biocal", "Cefim-3", "Cerox CV", "Citalam")

// Explicit demo data. Replace these catalogs with authorized API responses.
private val businessAreas = mapOf("Pharmaceuticals (demo)" to mapOf("Rajshahi (demo)" to mapOf("Sample Area (demo)" to listOf("Sample FME (demo)"))))

data class DcrEntry(val doctor: String, val fme: String, val date: String, val time: String, val brands: List<String>, val comment: String, val observation: String)

/** Offline-only persistence. No production network access or credentials are stored. */
private class LocalDraftStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("dcr_offline_drafts_v1", Context.MODE_PRIVATE)
    fun load(): List<DcrEntry> = try {
        val raw = prefs.getString("drafts", "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            val brands = obj.optJSONArray("brands") ?: JSONArray()
            DcrEntry(obj.optString("doctor"), obj.optString("fme"), obj.optString("date"),
                obj.optString("time"), (0 until brands.length()).map { brands.getString(it) },
                obj.optString("comment"), obj.optString("observation"))
        }
    } catch (_: Exception) { emptyList() }
    fun save(entries: List<DcrEntry>): Boolean = try {
        val array = JSONArray()
        entries.forEach { entry ->
            array.put(JSONObject().apply {
                put("doctor", entry.doctor); put("fme", entry.fme); put("date", entry.date)
                put("time", entry.time); put("brands", JSONArray(entry.brands))
                put("comment", entry.comment); put("observation", entry.observation)
            })
        }
        prefs.edit().putString("drafts", array.toString()).commit()
    } catch (_: Exception) { false }
}

private fun networkAvailable(context: Context): Boolean {
    val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = manager.activeNetwork ?: return false
    val capabilities = manager.getNetworkCapabilities(network) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { DcrApplication(LocalDraftStore(this), this) } }
}

@Composable
private fun DcrApplication(store: LocalDraftStore, context: Context) {
    var page by remember { mutableStateOf("Home") }
    val entries = remember { mutableStateListOf<DcrEntry>().apply { addAll(store.load()) } }
    var storageError by remember { mutableStateOf(false) }
    var connected by remember { mutableStateOf(networkAvailable(context)) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Background, surface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Background)) {
            Row(Modifier.fillMaxWidth().background(Blue).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                if (page != "Home") TextButton(onClick = { page = "Home" }) { Text("‹ Back", color = Color.White) }
                Text(if (page == "Home") "My DCRs" else page, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            when (page) {
                "Home" -> HomeScreen(connected, { connected = networkAvailable(context) }) { page = it }
                "Dashboard" -> DashboardScreen(entries)
                "Doctor Call Report" -> DcrScreen(context = context, onSaved = { entry ->
                    val updated = entries.toList() + entry
                    if (store.save(updated)) { entries.add(entry); page = "DCR History" }
                    else storageError = true
                })
                "DCR History" -> HistoryScreen(entries) { page = "Doctor Call Report" }
            }
            if (storageError) AlertDialog(onDismissRequest = { storageError = false },
                title = { Text("Draft not saved") },
                text = { Text("Local storage failed. Please retry. No data was sent to a server.") },
                confirmButton = { TextButton(onClick = { storageError = false }) { Text("OK") } })
        }
    }
}

@Composable private fun HomeScreen(connected: Boolean, refresh: () -> Unit, go: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Field Management", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Phase 5 • API contract gate; production integration disabled", color = Color.Gray)
        Text("Device network: ${if (connected) "available" else "unavailable"}. Server connection: not configured.", color = Color.Gray)
        OutlinedButton(onClick = refresh) { Text("Refresh network status") }
        HomeTile("Dashboard", "Weekly DCR performance and call vs plan") { go("Dashboard") }
        HomeTile("New Doctor Call Report", "Record a doctor visit") { go("Doctor Call Report") }
        HomeTile("DCR History", "View drafts retained after app restart") { go("DCR History") }
        Text("Phase 5 safety: login and server submission are disabled until staging verification. Do not enter real doctor data.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
    }
}
@Composable private fun HomeTile(title: String, subtitle: String, click: () -> Unit) {
    Card(onClick = click, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Blue, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = Color.DarkGray)
        }
    }
}

@Composable private fun DashboardScreen(entries: List<DcrEntry>) {
    val weekly = (1..4).map { week ->
        // No planned-call data is available locally. Do not infer completion percentages.
        val count = entries.count { e -> e.date.takeLast(2).toIntOrNull()?.let { day -> ((day - 1) / 7 + 1).coerceAtMost(4) == week } == true }
        week to count
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("DCR Call vs Plan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { MetricCard("Total DCR (offline drafts)", entries.size.toString(), "Plan: unavailable • Completion %: unavailable") }
        item { Text("Weekly activity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(weekly) { (week, count) -> MetricCard("Week $week", "$count DCR", "Plan and weekly percentage require backend data") }
        item { Text("Week grouping is a provisional 1–7 / 8–14 / 15–21 / 22–end-of-month convention, not verified against the original system.", style = MaterialTheme.typography.bodySmall, color = Color.Gray) }
    }
}
@Composable private fun MetricCard(title: String, value: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(value, color = Blue, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
    }
}

@Composable private fun DcrScreen(context: Context, onSaved: (DcrEntry) -> Unit) {
    var online by remember { mutableStateOf(networkAvailable(context)) }
    var business by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("") }
    var fme by remember { mutableStateOf("") }
    var doctor by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("") }
    var lastCall by remember { mutableStateOf("") }
    var visitDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var visitTime by remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale.US).format(Date())) }
    var workWith by remember { mutableStateOf("") }
    var other by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }
    var observation by remember { mutableStateOf("") }
    var selectedBrands by remember { mutableStateOf(setOf<String>()) }
    var showBrands by remember { mutableStateOf(false) }
    var confirmSave by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val regionOptions = businessAreas[business]?.keys?.toList().orEmpty()
    val areaOptions = businessAreas[business]?.get(region)?.keys?.toList().orEmpty()
    val fmeOptions = businessAreas[business]?.get(region)?.get(area).orEmpty()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Territory & Doctor", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item { ChoiceField("Business", business, businessAreas.keys.toList()) { business = it; region = ""; area = ""; fme = ""; doctor = "" } }
        item { ChoiceField("Region", region, regionOptions) { region = it; area = ""; fme = ""; doctor = "" } }
        item { ChoiceField("Area", area, areaOptions) { area = it; fme = ""; doctor = "" } }
        item { ChoiceField("FME", fme, fmeOptions) { fme = it; doctor = "" } }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Doctor lookup — API not configured", fontWeight = FontWeight.SemiBold, color = Blue)
                    Text(if (online) "Network available. Live doctor directory still requires a verified API." else "Offline: original app doctor list was unavailable in the same-form test. No cached directory is provided.", style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = { online = networkAvailable(context); if (!online) doctor = "" }) { Text("Recheck connectivity") }
                    OutlinedTextField(doctor, { doctor = it }, label = { Text("Doctor (manual demo only)") }, modifier = Modifier.fillMaxWidth(), enabled = fme.isNotBlank() && online, singleLine = true)
                    Text("Manual doctor entry is for non-sensitive UI testing only; it is not a verified server doctor selection.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
        }
        item { OutlinedTextField(priority, { priority = it }, label = { Text("Priority (unverified)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { OutlinedTextField(lastCall, { lastCall = it }, label = { Text("Last call (unverified)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { Text("Visit Information", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(visitDate, { visitDate = it }, label = { Text("Visit date YYYY-MM-DD") }, modifier = Modifier.weight(1.5f), singleLine = true)
                OutlinedTextField(visitTime, { visitTime = it }, label = { Text("Time HH:mm") }, modifier = Modifier.weight(1f), singleLine = true)
            }
        }
        item { OutlinedButton(onClick = { showBrands = true }, modifier = Modifier.fillMaxWidth()) { Text("+ TARGET BRAND (${selectedBrands.size})") } }
        if (selectedBrands.isNotEmpty()) item { Text("Selected: ${selectedBrands.sorted().joinToString(", ")}", color = Blue) }
        item { ChoiceField("Work with", workWith, listOf("Alone (demo)", "Colleague (demo)", "Other (demo)")) { workWith = it } }
        item { OutlinedTextField(other, { other = it }, label = { Text("Other") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(comment, { comment = it }, label = { Text("Doctor comment") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
        item { OutlinedTextField(observation, { observation = it }, label = { Text("Your observation") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
        if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
        item {
            Button(onClick = {
                error = when {
                    !online && doctor.isBlank() -> "Doctor lookup unavailable offline. Reconnect to select a doctor."
                    business.isBlank() || region.isBlank() || area.isBlank() || fme.isBlank() || doctor.isBlank() -> "Complete Business, Region, Area, FME and Doctor."
                    !isValidDate(visitDate) -> "Enter a valid visit date (YYYY-MM-DD)."
                    !Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(visitTime) -> "Enter visit time as HH:mm."
                    else -> ""
                }
                if (error.isBlank()) confirmSave = true
            }, modifier = Modifier.fillMaxWidth()) { Text("Review & Save Offline Draft") }
        }
        item { Text("Demo catalogs and validations are provisional. No network submission is performed. Drafts persist on this device.", style = MaterialTheme.typography.bodySmall, color = Color.Gray) }
    }
    if (showBrands) BrandPicker(selectedBrands, onDismiss = { showBrands = false }, onDone = { selectedBrands = it; showBrands = false })
    if (confirmSave) AlertDialog(onDismissRequest = { confirmSave = false }, title = { Text("Save local DCR draft?") }, text = { Text("Doctor: $doctor\nBrands: ${selectedBrands.sorted().joinToString().ifBlank { "None" }}\nThis will not submit to the server.") }, confirmButton = {
        TextButton(onClick = { confirmSave = false; onSaved(DcrEntry(doctor, fme, visitDate, visitTime, selectedBrands.sorted(), comment, observation)) }) { Text("Save Draft") }
    }, dismissButton = { TextButton(onClick = { confirmSave = false }) { Text("Cancel") } })
}
private fun isValidDate(date: String): Boolean = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(date) != null && Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(date) } catch (_: Exception) { false }

@Composable private fun ChoiceField(label: String, selected: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        OutlinedButton(onClick = { expanded = true }, enabled = options.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${selected.ifBlank { "Select" }}", modifier = Modifier.weight(1f))
            Text("⌄")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false }) }
        }
    }
}

@Composable private fun BrandPicker(initial: Set<String>, onDismiss: () -> Unit, onDone: (Set<String>) -> Unit) {
    var query by remember { mutableStateOf("") }
    val checked = remember { mutableStateListOf<String>().apply { addAll(initial) } }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Target Brands") }, text = {
        Column {
            OutlinedTextField(query, { query = it }, label = { Text("Search brands") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(Brands.filter { it.contains(query, ignoreCase = true) }) { brand ->
                    Row(Modifier.fillMaxWidth().clickable { if (brand in checked) checked.remove(brand) else checked.add(brand) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(brand, modifier = Modifier.weight(1f))
                        Checkbox(checked = brand in checked, onCheckedChange = { if (it) { if (brand !in checked) checked.add(brand) } else checked.remove(brand) })
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { onDone(checked.toSet()) }) { Text("DONE") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL") } })
}

@Composable private fun HistoryScreen(entries: List<DcrEntry>, newDcr: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Button(onClick = newDcr, modifier = Modifier.fillMaxWidth()) { Text("+ New DCR") } }
        if (entries.isEmpty()) item { MetricCard("No local drafts", "0", "Create a preview DCR to see it here.") }
        items(entries.reversed()) { entry ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(entry.doctor, fontWeight = FontWeight.Bold, color = Blue)
                    Text("${entry.date} ${entry.time} • ${entry.fme}")
                    Text("Brands: ${entry.brands.joinToString().ifBlank { "None" }}")
                    if (entry.comment.isNotBlank()) Text("Doctor comment: ${entry.comment}")
                    if (entry.observation.isNotBlank()) Text("Observation: ${entry.observation}")
                    Text("OFFLINE DRAFT • NOT SUBMITTED", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
            }
        }
    }
}
